---
name: botin-brand
description: Brand guidelines and assets for El Botín del Alicanto (botin.cl). Use whenever creating any document, presentation, social post, web page, flyer, signage or image for Botín, so it uses the correct logo, colors, typography, character and voice.
---

# El Botín del Alicanto: brand guidelines

El Botín del Alicanto (short name: **Botín**, web: botin.cl) places vending machines with sealed collectibles (toys, TCG cards, collectibles, blind boxes) where people already are, with stock that changes and is announced. Each machine is a **veta** (vein); the alicanto, a bird from northern Chilean legend that feeds on gold and silver, flies from veta to veta leaving treasure. Founding team: led Zmart Games for more than 20 years.

Brand idea: **la búsqueda es el botín**. The fun is finding the machine, seeing what's in it this week and opening the capsule. The brand is clear and legible; the surprise lives inside the capsule, never in the interface.

Use these guidelines for every output. When something isn't covered here, keep the result close to botin.cl.

## Logo

Files in `assets/logo/` (logo pack release 1, 2026-11-18; all vector files are outlined, no live text):

| File | Use |
|---|---|
| `lockup.svg` / `lockup.png` | Main lockup (isotipo + BOTÍN + DEL ALICANTO), transparent background, for dark backgrounds |
| `lockup-sobre-noche.png` | Same lockup on Noche, ready to drop in |
| `isotipo.svg` / `isotipo.png` | Color isotipo, for dark or light backgrounds |
| `isotipo-mono.svg` / `isotipo-mono.png` | One-ink isotipo in Noche, eyes and beak cut out, for light backgrounds and single-color print |

Rules:
- The isotipo is the most important piece of the brand. **It always accompanies the logotipo.** Never use the BOTÍN wordmark alone without the bird.
- The isotipo alone is fine in small spaces: avatar, favicon, machine seal, page corner.
- The tilde of the Í in BOTÍN is the isotipo's crest (three diamonds), never a regular accent.
- The gold lockup goes on dark backgrounds only. There is no light-background lockup yet: on light backgrounds use the isotipo alone (color or mono) and say so.
- Do not redraw, recolor, stretch, rotate, outline or add effects to the logo. Do not use the old August 2026 heraldic logo or any earlier version of the isotipo.
- Never rebuild the lockup with live text. For HTML outputs use `lockup.svg` or `isotipo.svg`; for documents and slides the PNGs are fine.

## Color

| Name | Hex | Role |
|---|---|---|
| Noche | `#192648` | Default background for everything |
| Noche profunda | `#121C38` / `#0B1430` | Panels, cards, deeper sections |
| Oro | `#E8B53A` | Logo, headlines, key accents |
| Oro vivo | `#F7D98A` | Highlights, glow, emphasis on dark |
| Plata | `#B9C2D2` | "DEL ALICANTO", secondary text, rules |
| Blanco hueso | `#F3F1EA` | Body text on dark; background for light pieces |
| Verde mineral | `#2FB39A` | Interface states only (new stock, machine available). Never decorative |
| Texto 2 / 3 | `#B4BCD0` / `#8790A8` | Secondary and tertiary text on dark |

- **Gold is never a background; it is light.** Always on dark.
- Default background is Noche, not white. Use Blanco hueso as background only for documents meant to be printed in volume or read at length.
- No gradients other than subtle Noche to Noche profunda. No neon, no fire colors.

Tokens ready to use: `reference/tokens.css`.

## Typography

Both families are free (SIL Open Font License, `assets/fonts/OFL-ChakraPetch.txt` and `OFL-BaiJamjuree.txt`), in `assets/fonts/`, and on Google Fonts.

- **Chakra Petch** (600/700): headlines, numbers, veta codes, labels, buttons. Uppercase for short labels and codes.
- **Bai Jamjuree** (400/500/600): all running text.
- If the output can't embed fonts (for example a .docx opened elsewhere), fall back to Arial Narrow for headlines and Arial for text, and say so.

Google Fonts link for HTML:
`https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;500;600&family=Chakra+Petch:wght@500;600;700&display=swap`

## Shapes and system

- Two base shapes: the **escalón** (stepped edge, like an open-pit mine) and the **rombo** (diamond, slightly elongated like the crest). Use diamonds as bullets, separators and markers.
- Structure is angular (mine, metro, information); the character is round (play, warmth). That contrast is the brand.
- **Veta codes**: each machine has a short code like a metro station, `V07`, set in Chakra Petch. Use example places and codes clearly marked as examples unless the user gives real ones.
- **Ficha de veta** (machine card): where the machine is, which collection it has, how many models and which one is rare.
- **Mapa de vetas**: the trail drawn as a metro line connecting vetas.

## The character

The mascot is the alicanto itself, illustrated. Reference sheet: `assets/character/ficha-maestra.png`. Approved poses (transparent PNG):

`pose-vuelo` (flying), `pose-maquina` (on a machine), `pose-capsula` (in a capsule), `pose-pepita` (holding a nugget), `pose-senalando` (pointing), `pose-durmiendo` (sleeping on the treasure).

Fixed traits, always:
1. Round, chubby golden body with an oval bone-white belly, pink cheeks, small orange beak, simple black eyes.
2. Crest of **three crystal diamonds**: tall one in the center, two smaller ones tilted out.
3. Brown leather **messenger bag**, strap over his right shoulder, bag on his **left hip**, flap open and folded back with treasure peeking out.
4. Short rounded wings with glowing tips, long ribbon-like tail that glows. Light, never fire.

Behavior: he is a delivery bird, not a thief or a clumsy one. **He leaves nuggets, he doesn't lose them**: the trail is an ordered line pointing to a machine, never a scattered mess, and nothing falls from the tail.

Rules:
- Use the existing poses as they are. Never flip them horizontally (it moves the bag to the wrong side), never recolor, crop through the crest or add props.
- If a new illustration is needed, describe it from the traits above and the reference sheet, and present it as a draft for approval. Never mix in third-party characters or logos.

## Voice

Speak like an experienced treasure hunter, not like a salesperson. Chilean Spanish, tú form, short and warm sentences, no corporate filler.

- Claim: **Sigue el rastro.**
- Tagline: **Tesoros que se cazan.**
- Signature line (once, origin page or manual): **El alicanto sabe dónde está el botín.**
- CTAs: web and bio "Busca tu botín"; machine screen "Elige y abre"; email capture "Avísame cuando llegue"; user content "Muestra lo que te salió".
- Founders line, used as written: "parte del equipo que lideró Zmart Games por más de 20 años".
- Mining vocabulary is welcome when it reads naturally: veta, pepita, rastro, botín, la mina (warehouse). Don't force it into every sentence.
- Never promise what a machine has unless the stock is given. The mystery is which item you get, not whether the trip is worth it.
- Product brands (Pokémon, Magic, Pop Mart, etc.) can be named as what's sold, but their logos and characters are never part of Botín's graphics.

## Contact and channels

- Web: botin.cl
- Email: contacto@botin.cl
- Instagram and TikTok: @botin.cl · X: @botincl

## Checklist before delivering

- Logo present, with the isotipo, and on the right background.
- Noche as background, gold as light, green only for states.
- Chakra Petch for headlines, Bai Jamjuree for text.
- Character traits correct, bag on the left hip, not flipped.
- Any text not provided by the user and not in this guide is marked as a draft.
