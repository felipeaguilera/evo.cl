# Logo pack: release 1 (2026-11-18)

| File | Uso |
|---|---|
| BDA-Iso-v1g.svg / .af | Isotipo a color, maestro. Fondo Noche. |
| BDA-Iso-Mono-v1g.svg | Isotipo a una tinta (Noche #192648), ojos y pico calados. Para fondos claros. |
| BDA-Lockup-v1g.svg | Isotipo v1g + logotipo, horizontal. |
| BDA-Logotype-v1a.svg | Logotipo solo. Vigente por ahora, pendiente de pulir. |

Versiones anteriores en `_archive/`.

## PNG exports (`png/`)

Generados desde los SVG de release 1, fondo transparente salvo el de Noche.

| File | Tamaño | Uso |
|---|---|---|
| png/BDA-Iso-v1g.png | 950 × 1024 | Isotipo a color |
| png/BDA-Iso-Mono-v1g.png | 950 × 1024 | Isotipo a una tinta, fondos claros |
| png/BDA-Lockup-v1g.png | 2000 × 737 | Lockup, para fondos oscuros |
| png/BDA-Lockup-Noche-v1g.png | 2000 × 933 | Lockup sobre Noche #192648, listo para usar |

El brand skill vigente (`Kit/BDA-BrandSkill-v1b.zip`) lleva estos mismos archivos con nombres genéricos (`isotipo`, `isotipo-mono`, `lockup`, `lockup-sobre-noche`).
