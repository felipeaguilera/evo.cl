---
name: ransumi-brand
description: Brand guidelines and assets for RANSUMI (ransumi.com), the design orchid pot. Use whenever creating any label, packaging, document, presentation, social post, web page, merch or image for RANSUMI, so it uses the correct logo, colors, typography and text rules.
---

# RANSUMI: brand guidelines

RANSUMI is the product brand of a design pot for orchids (descriptor: **Macetero para orquídeas**), open so air reaches the roots. It solves both the care of the plant and how it looks at home. Web: **ransumi.com**.

The name: **Ran**, orchid, and **sumi**, the ink of sumi-e. In Japanese it is written only in katakana: **ランスミ**.

Brand idea: **Donde lo técnico y lo orgánico se encuentran.**

The main customer is a woman aged 50 or over.

Source of every rule below: the approved brand kit page, evo.cl/clientes/ransumi/brand-kit/ (v1, November 2026). Anything marked **PROPOSAL** is not in that page and has not been approved by the client.

## The symbol

- **The flower**: one single orchid, symmetrical as it is in nature. Interior detail is cut out of the mass, never drawn on top.
- **The open container**: a hexagon open at its vertices, like the pot. The gaps are where the air comes in.
- **Stem and root**: the stem crosses the bottom opening and ends in a node. The plant grows beyond its container.
- **Restraint**: few colors, a lot of air. Empty space is part of the design, as in sumi-e.

## Logo

Files in `assets/logo/` (all vectors are outlined, no live text; PNGs are transparent):

| File | Use |
|---|---|
| `lockup-vertical.svg` / `.png` | Main version. Isotipo + RANSUMI, color. For light backgrounds |
| `lockup-vertical-one-ink.svg` / `.png` | Everything in Verde `#03502A`. For merch and one-color print |
| `isotipo.svg` / `.png` | Color isotipo. Avatar, favicon, spaces where the name is already present |
| `isotipo-one-ink.svg` / `.png` | Everything in Verde. For one-color print |
| `wordmark.svg` / `.png` | RANSUMI alone, in Verde. For very horizontal formats and headers |

Rules:
- In the color version, magenta goes only on the flower.
- Merch always uses the one-ink version.
- HTML outputs use the SVGs; documents and presentations can use the PNGs.
- There is no horizontal version and no negative version yet. Do not create them; if a piece needs one, say so.
- Never redraw, recolor, stretch, rotate, outline or add effects to the logo.
- Never rebuild the lockup with live text.
- Do not use the August 2026 explorations or any earlier version of the symbol.

## Color

| Name | Hex | Role |
|---|---|---|
| Verde | `#03502A` | Logo, container, stem, text. Everything that is not the flower |
| Magenta | `#AB0745` | Only the flower in the logo and the mouth in the top-view drawing of the pot |
| Crema | `#F9F3EC` | Background for light pieces |

- Magenta lives only in the flower. Everything else is green.
- Merch is always one color: crema on green, or green on undyed (natural) fabric.
- No gradients: they don't print.

Tokens ready to use: `reference/tokens.css`. The neutral interface values in that file come from the brand kit page layout and are a PROPOSAL outside it.

## Typography

Both families are free (SIL Open Font License, `assets/fonts/OFL-ZenKakuGothicNew.txt` and `OFL-Inter.txt`), included as TTF in `assets/fonts/`, and on Google Fonts.

- **Zen Kaku Gothic New Medium 500**: model name and the katakana ランスミ. Never Light: it breaks in screen printing.
- **Inter** (Regular 400, Medium 500, SemiBold 600): everything else. Supporting text, product sheets, labels.
- No fonts that imitate brush lettering. The Japanese character comes from composition and air, not from the letterforms.

Print scale (from the approved box label):

| Element | Font | Size |
|---|---|---|
| Model name (e.g. Hexagon) | Zen Kaku Gothic New Medium | 36 pt |
| ランスミ on the lid | Zen Kaku Gothic New Medium | 15 pt, tracking 0.12em |
| Product sheet values (e.g. Terracotta) | Inter SemiBold | 12 pt |
| Labels (e.g. COLOR) | Inter SemiBold | 7.5 pt, uppercase, tracking 0.14em |

- Supporting text never below 7.5 pt.
- Make what exists bigger; do not add content.
- PROPOSAL: if the output can't embed fonts (for example a .docx opened elsewhere), fall back to Arial for everything and say so.

Google Fonts link for HTML:
`https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Zen+Kaku+Gothic+New:wght@400;500&display=swap`

## Text rules

- The name is written **RANSUMI**, in capitals. In Japanese, only **ランスミ**, with no translation or subtitle.
- The brand's web is **ransumi.com**.
- Product colors are always named in English: Translucent, Dark Bronze, Terracotta, Black Matte, Calm Sand.
- No registration symbols (® or ™) while the trademark registration is in process. Copyright only: **© 2026 RANSUMI**.
- RANSUMI pieces never carry the store's brand, domain or Instagram.

## Voice

There is no approved verbal identity yet. Use only copy given by the user or written in this guide.

- PROPOSAL: write in Chilean Spanish, tú form, short and calm sentences, describing the product as it is, without claims the user hasn't given.

## Contact and channels

- Web: ransumi.com
- No brand email or social accounts are defined in the kit. Do not invent them.

## Checklist before delivering

- Logo present, from `assets/logo/`, never rebuilt with live text.
- Magenta only on the flower; everything else in Verde.
- Merch and one-color print use the one-ink version.
- Zen Kaku Gothic New Medium only for the model name and ランスミ; Inter for the rest; nothing below 7.5 pt.
- RANSUMI in capitals, product colors in English, no ® or ™.
- Any text not provided by the user and not in this guide is marked as a draft.
